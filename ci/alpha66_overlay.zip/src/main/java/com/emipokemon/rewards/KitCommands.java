package com.emipokemon.rewards;

import com.emipokemon.Emipokemon;
import com.emipokemon.config.EmipokemonConfig;
import com.emipokemon.data.PlayerData;
import com.emipokemon.progress.JobAccessPolicy;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.time.Duration;
import java.util.Locale;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/** Server-authoritative, LuckPerms-aware reclaimable kits. */
public final class KitCommands {
    private KitCommands() { }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, access, environment) -> register(dispatcher));
    }

    private static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("kits").executes(context -> list(context.getSource())));
        dispatcher.register(literal("kit")
                .then(argument("id", StringArgumentType.word())
                        .suggests((context, builder) -> {
                            for (EmipokemonConfig.KitDefinition kit : Emipokemon.configManager().get().kits.definitions)
                                builder.suggest(kit.id);
                            return builder.buildFuture();
                        })
                        .executes(context -> claim(context.getSource(), StringArgumentType.getString(context, "id")))));
    }

    private static int list(ServerCommandSource source) {
        ServerPlayerEntity player;
        try { player = source.getPlayerOrThrow(); }
        catch (Exception exception) { source.sendError(Text.literal("Este comando es solo para jugadores.")); return 0; }
        EmipokemonConfig.KitSettings settings = Emipokemon.configManager().get().kits;
        if (!settings.enabled) { source.sendError(Text.literal("Los kits están desactivados.")); return 0; }
        player.sendMessage(Text.literal("§d§lKits Emipokemon §7— usa §f/kit <id>"), false);
        PlayerData data = Emipokemon.playerDataManager().getOrLoad(player.getUuid());
        long now = System.currentTimeMillis();
        for (EmipokemonConfig.KitDefinition kit : settings.definitions) {
            boolean permitted = permitted(player, kit);
            long remaining = remainingMillis(data, kit, now);
            String state = !permitted ? "§cSIN PERMISO" : remaining <= 0L ? "§aDISPONIBLE" : "§e" + format(remaining);
            player.sendMessage(Text.literal(" §8• §f" + kit.id + " §7— " + kit.displayName + " §8[" + state + "§8]"), false);
        }
        return 1;
    }

    private static int claim(ServerCommandSource source, String requestedId) {
        ServerPlayerEntity player;
        try { player = source.getPlayerOrThrow(); }
        catch (Exception exception) { source.sendError(Text.literal("Este comando es solo para jugadores.")); return 0; }
        EmipokemonConfig.KitSettings settings = Emipokemon.configManager().get().kits;
        if (!settings.enabled) { source.sendError(Text.literal("Los kits están desactivados.")); return 0; }
        String id = requestedId.toLowerCase(Locale.ROOT);
        EmipokemonConfig.KitDefinition kit = settings.definitions.stream()
                .filter(candidate -> candidate.id.equals(id)).findFirst().orElse(null);
        if (kit == null) { source.sendError(Text.literal("Kit desconocido. Usa /kits.")); return 0; }
        if (!permitted(player, kit)) {
            source.sendError(Text.literal("No tienes el permiso " + kit.permission + "."));
            return 0;
        }
        PlayerData data = Emipokemon.playerDataManager().getOrLoad(player.getUuid());
        long now = System.currentTimeMillis();
        long remaining = remainingMillis(data, kit, now);
        if (remaining > 0L) {
            source.sendError(Text.literal("Podrás reclamar este kit en " + format(remaining) + "."));
            return 0;
        }
        for (String entry : kit.items) give(player, entry);
        data.kitClaims.put(kit.id, now);
        Emipokemon.playerDataManager().saveNow(player.getUuid());
        player.sendMessage(Text.literal("§aKit reclamado: §f" + kit.displayName), false);
        return 1;
    }

    private static boolean permitted(ServerPlayerEntity player, EmipokemonConfig.KitDefinition kit) {
        return player.hasPermissionLevel(4) || JobAccessPolicy.hasPermission(player, kit.permission);
    }

    private static long remainingMillis(PlayerData data, EmipokemonConfig.KitDefinition kit, long now) {
        Long last = data.kitClaims.get(kit.id);
        if (last == null) return 0L;
        if (kit.cooldownHours == 0) return Long.MAX_VALUE;
        return Math.max(0L, last + Duration.ofHours(kit.cooldownHours).toMillis() - now);
    }

    private static String format(long millis) {
        if (millis == Long.MAX_VALUE) return "YA RECLAMADO";
        long minutes = Math.max(1L, Duration.ofMillis(millis).toMinutes());
        long hours = minutes / 60L;
        long remainder = minutes % 60L;
        return hours > 0L ? hours + "h " + remainder + "m" : minutes + "m";
    }

    private static void give(ServerPlayerEntity player, String encoded) {
        int separator = encoded.lastIndexOf('*');
        Identifier id = Identifier.tryParse(separator < 0 ? encoded : encoded.substring(0, separator));
        int count = separator < 0 ? 1 : Integer.parseInt(encoded.substring(separator + 1));
        Item item = id == null ? null : Registries.ITEM.getOrEmpty(id).orElse(null);
        if (item == null) {
            Emipokemon.LOGGER.warn("Kit {} skipped missing item {}", player.getName().getString(), encoded);
            return;
        }
        while (count > 0) {
            int amount = Math.min(count, item.getMaxCount());
            ItemStack stack = new ItemStack(item, amount);
            if (!player.getInventory().insertStack(stack) && !stack.isEmpty()) player.dropItem(stack, false);
            count -= amount;
        }
    }
}
