package com.emipokemon.gacha;

import com.emipokemon.Emipokemon;
import com.emipokemon.data.PlayerData;
import com.emipokemon.gacha.banner.BannerDefinition;
import com.emipokemon.gacha.machine.GachaMachineBlockEntity;
import com.emipokemon.registry.ModRegistries;
import com.emipokemon.rewards.RewardWalletService;
import com.google.gson.Gson;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.item.Item;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

/** Opens and executes the x1/x10 gacha UI while keeping every roll authoritative on the server. */
public final class GachaNetworking {
    private static final Gson GSON = new Gson();

    private GachaNetworking() { }

    public static void initializeServer() {
        PayloadTypeRegistry.playS2C().register(OpenGachaPayload.ID, OpenGachaPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(GachaActionPayload.ID, GachaActionPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(GachaActionPayload.ID,
                (payload, context) -> context.server().execute(() -> action(context.player(), payload)));
    }

    public static void open(ServerPlayerEntity player, GachaMachineBlockEntity machine, String message) {
        send(player, state(player, machine, message, List.of()));
    }

    private static void action(ServerPlayerEntity player, GachaActionPayload payload) {
        int count = payload.count();
        if (count != 1 && count != 10) return;
        BlockPos pos = BlockPos.fromLong(payload.blockPos());
        if (player.squaredDistanceTo(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) > 64.0D) {
            player.sendMessage(Text.literal("§cDebes permanecer cerca de la máquina gacha."), false);
            return;
        }
        if (!(player.getServerWorld().getBlockEntity(pos) instanceof GachaMachineBlockEntity machine)) {
            player.sendMessage(Text.literal("§cLa máquina gacha ya no está disponible."), false);
            return;
        }
        BannerDefinition banner = Emipokemon.bannerManager().get(machine.getBannerId());
        if (banner == null || !banner.activeNow()) {
            open(player, machine, "§cEl banner está desactivado o ya terminó.");
            return;
        }
        ArrayList<ResultView> results = new ArrayList<>();
        String message = "";
        for (int index = 0; index < count; index++) {
            GachaService.PullOutcome outcome = Emipokemon.gachaService().pullWithCurrencyOverride(
                    player, banner.id, currency(player, machine));
            if (!outcome.success()) {
                message = (results.isEmpty() ? "§c" : "§e") + outcome.error();
                break;
            }
            GachaRollResult result = outcome.result();
            results.add(new ResultView(result.pokemon().speciesId(), result.pokemon().displayName(),
                    result.tier().name(), result.level(), result.shiny()));
        }
        if (!results.isEmpty()) message = "§a" + results.size() + " tirada" + (results.size() == 1 ? " completada." : "s completadas.");
        send(player, state(player, machine, message, results));
    }

    private static BannerDefinition.Currency currency(ServerPlayerEntity player, GachaMachineBlockEntity machine) {
        boolean emi = machine.requiresEmiTicket();
        String walletType = emi ? RewardWalletService.EMI : RewardWalletService.STANDARD;
        BannerDefinition.Currency cost = new BannerDefinition.Currency();
        if (Emipokemon.rewardWalletService().balance(player, walletType) > 0L) {
            cost.type = walletType;
            cost.itemId = "";
        } else {
            cost.type = "ITEM";
            cost.itemId = emi ? "emipokemon:emi_special_banner_ticket" : "emipokemon:gacha_ticket";
        }
        cost.amount = 1;
        cost.normalize();
        return cost;
    }

    private static GachaView state(ServerPlayerEntity player, GachaMachineBlockEntity machine,
                                   String message, List<ResultView> results) {
        BannerDefinition banner = Emipokemon.bannerManager().get(machine.getBannerId());
        boolean emi = machine.requiresEmiTicket();
        Item ticket = emi ? ModRegistries.EMI_SPECIAL_BANNER_TICKET : ModRegistries.GACHA_TICKET;
        String wallet = emi ? RewardWalletService.EMI : RewardWalletService.STANDARD;
        long tickets = player.getInventory().count(ticket) + Emipokemon.rewardWalletService().balance(player, wallet);
        PlayerData data = Emipokemon.playerDataManager().getOrLoad(player.getUuid());
        GachaProgress progress = data.gacha(machine.getBannerId());
        int epicMax = banner == null ? 0 : banner.pity.epicGuarantee;
        int legendaryMax = banner == null ? 0 : banner.pity.hardLegendaryGuarantee;
        return new GachaView(machine.getPos().asLong(), machine.getBannerId(),
                banner == null ? machine.getBannerId() : banner.displayName, emi, tickets,
                progress.totalPulls, progress.pullsSinceEpicOrBetter, epicMax,
                progress.pullsSinceLegendaryOrBetter, legendaryMax,
                message == null ? "" : message, results);
    }

    private static void send(ServerPlayerEntity player, GachaView view) {
        if (ServerPlayNetworking.canSend(player, OpenGachaPayload.ID))
            ServerPlayNetworking.send(player, new OpenGachaPayload(GSON.toJson(view)));
    }

    public record GachaView(long blockPos, String bannerId, String bannerName, boolean emi,
                            long tickets, long totalPulls, int epicPity, int epicMaximum,
                            int legendaryPity, int legendaryMaximum, String message,
                            List<ResultView> results) { }

    public record ResultView(String speciesId, String name, String tier, int level, boolean shiny) { }

    public record OpenGachaPayload(String json) implements CustomPayload {
        public static final Id<OpenGachaPayload> ID = new Id<>(Identifier.of(Emipokemon.MOD_ID, "open_gacha"));
        public static final PacketCodec<RegistryByteBuf, OpenGachaPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.STRING, OpenGachaPayload::json, OpenGachaPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    public record GachaActionPayload(long blockPos, int count) implements CustomPayload {
        public static final Id<GachaActionPayload> ID = new Id<>(Identifier.of(Emipokemon.MOD_ID, "gacha_action"));
        public static final PacketCodec<RegistryByteBuf, GachaActionPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_LONG, GachaActionPayload::blockPos,
                PacketCodecs.VAR_INT, GachaActionPayload::count,
                GachaActionPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }
}
