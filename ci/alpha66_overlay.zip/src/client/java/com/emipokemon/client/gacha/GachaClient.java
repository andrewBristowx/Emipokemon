package com.emipokemon.client.gacha;

import com.emipokemon.Emipokemon;
import com.emipokemon.gacha.GachaNetworking.GachaActionPayload;
import com.emipokemon.gacha.GachaNetworking.GachaView;
import com.emipokemon.gacha.GachaNetworking.OpenGachaPayload;
import com.google.gson.Gson;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

public final class GachaClient {
    private static final Gson GSON = new Gson();

    private GachaClient() { }

    public static void initialize() {
        ClientPlayNetworking.registerGlobalReceiver(OpenGachaPayload.ID, (payload, context) ->
                context.client().execute(() -> open(payload.json())));
    }

    static void pull(long blockPos, int count) {
        if (ClientPlayNetworking.canSend(GachaActionPayload.ID))
            ClientPlayNetworking.send(new GachaActionPayload(blockPos, count));
    }

    private static void open(String json) {
        try {
            GachaView view = GSON.fromJson(json, GachaView.class);
            if (view == null) return;
            MinecraftClient client = MinecraftClient.getInstance();
            Screen current = client.currentScreen;
            Screen parent = current instanceof GachaScreen gacha ? gacha.parent() : current;
            client.setScreen(new GachaScreen(parent, view));
        } catch (Exception exception) {
            Emipokemon.LOGGER.error("Could not open gacha screen", exception);
        }
    }
}
