package com.emipokemon.client.gacha;

import com.emipokemon.Emipokemon;
import com.emipokemon.client.render.PokemonPortraitRenderer;
import com.emipokemon.gacha.GachaNetworking.GachaView;
import com.emipokemon.gacha.GachaNetworking.ResultView;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

/** Responsive x1/x10 gacha presentation with the user-provided reveal animation. */
final class GachaScreen extends Screen {
    private static final int REF_W = 1536;
    private static final int REF_H = 1024;
    private static final int FRAME_W = 384;
    private static final int FRAME_H = 216;
    private static final int FRAME_COLUMNS = 8;
    private static final int FRAME_COUNT = 46;
    private static final long FRAME_MILLIS = 1_000L / 12L;
    private static final long REVEAL_MILLIS = FRAME_COUNT * FRAME_MILLIS;
    private static final Identifier NORMAL = Identifier.of(Emipokemon.MOD_ID, "textures/gui/gacha/standard_gacha.png");
    private static final Identifier EMI = Identifier.of(Emipokemon.MOD_ID, "textures/gui/gacha/emi_gacha.png");
    private static final Identifier REVEAL = Identifier.of(Emipokemon.MOD_ID, "textures/gui/gacha/reveal_sheet.png");

    private final Screen parent;
    private final GachaView view;
    private final long revealStartedAt;
    private int panelX, panelY, panelW, panelH;
    private boolean requesting;

    GachaScreen(Screen parent, GachaView view) {
        super(Text.literal("Gacha Emipokemon"));
        this.parent = parent;
        this.view = view;
        this.revealStartedAt = view.results() == null || view.results().isEmpty() ? 0L : System.currentTimeMillis();
    }

    Screen parent() { return parent; }

    @Override
    protected void init() {
        float scale = Math.min((width - 12.0F) / REF_W, (height - 12.0F) / REF_H);
        panelW = Math.max(1, Math.round(REF_W * scale));
        panelH = Math.max(1, Math.round(REF_H * scale));
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
        addDrawableChild(new Hotspot(panelX + rx(240), panelY + ry(842), rx(410), ry(132), Text.literal("Tirar una vez"), b -> request(1)));
        addDrawableChild(new Hotspot(panelX + rx(670), panelY + ry(842), rx(410), ry(132), Text.literal("Tirar diez veces"), b -> request(10)));
        addDrawableChild(ButtonWidget.builder(Text.literal("×"), button -> close())
                .dimensions(panelX + panelW - rx(55), panelY + ry(18), rx(36), ry(30)).build());
    }

    private void request(int count) {
        if (requesting || animating()) return;
        requesting = true;
        GachaClient.pull(view.blockPos(), count);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, 0xE0000000);
        context.drawTexture(view.emi() ? EMI : NORMAL, panelX, panelY, panelW, panelH,
                0, 0, REF_W, REF_H, REF_W, REF_H);
        drawLabels(context);
        if (animating()) drawRevealAnimation(context);
        else if (view.results() != null && !view.results().isEmpty()) drawResults(context, view.results());
        else drawEmptyStage(context);
        super.render(context, mouseX, mouseY, delta);
    }

    private void drawLabels(DrawContext context) {
        int titleX = panelX + rx(760);
        drawCentered(context, view.emi() ? "GACHA ESPECIAL DE EMI" : "GACHA COBBLEMON", titleX, panelY + ry(35), 0xFFFFFFFF);
        drawCentered(context, view.bannerName(), titleX, panelY + ry(70), view.emi() ? 0xFFFFC4EE : 0xFF8DEBFF);
        int sideX = panelX + rx(1325);
        drawCentered(context, (view.emi() ? "TICKETS EMI: " : "TICKETS: ") + view.tickets(), sideX, panelY + ry(130), 0xFFFFE8A8);
        drawCentered(context, "PITY ÉPICO", sideX, panelY + ry(245), 0xFFFFD46D);
        drawCentered(context, view.epicPity() + " / " + view.epicMaximum(), sideX, panelY + ry(285), 0xFFFFFFFF);
        drawCentered(context, "PITY LEGENDARIO", sideX, panelY + ry(430), 0xFFFFD46D);
        drawCentered(context, view.legendaryPity() + " / " + view.legendaryMaximum(), sideX, panelY + ry(470), 0xFFFFFFFF);
        drawCentered(context, "TIRADAS TOTALES", sideX, panelY + ry(615), 0xFFFFD46D);
        drawCentered(context, Long.toString(view.totalPulls()), sideX, panelY + ry(655), 0xFFFFFFFF);
        drawCentered(context, "TIRAR ×1", panelX + rx(445), panelY + ry(900), 0xFFFFFFFF);
        drawCentered(context, "1 TICKET", panelX + rx(445), panelY + ry(938), 0xFFFFE8A8);
        drawCentered(context, "TIRAR ×10", panelX + rx(875), panelY + ry(900), 0xFFFFFFFF);
        drawCentered(context, "10 TICKETS", panelX + rx(875), panelY + ry(938), 0xFFFFE8A8);
        if (requesting) drawCentered(context, "PROCESANDO…", panelX + rx(760), panelY + ry(805), 0xFFFFFFFF);
        else if (view.message() != null && !view.message().isBlank())
            drawCentered(context, view.message(), panelX + rx(760), panelY + ry(805), 0xFFFFFFFF);
    }

    private void drawRevealAnimation(DrawContext context) {
        long elapsed = Math.max(0L, System.currentTimeMillis() - revealStartedAt);
        int frame = Math.min(FRAME_COUNT - 1, (int) (elapsed / FRAME_MILLIS));
        int sourceX = frame % FRAME_COLUMNS * FRAME_W;
        int sourceY = frame / FRAME_COLUMNS * FRAME_H;
        int x = panelX + rx(300), y = panelY + ry(250), w = rx(760), h = ry(428);
        context.fill(x - 3, y - 3, x + w + 3, y + h + 3, 0xFF120A22);
        context.drawTexture(REVEAL, x, y, w, h, sourceX, sourceY, FRAME_W, FRAME_H,
                FRAME_COLUMNS * FRAME_W, 6 * FRAME_H);
    }

    private void drawResults(DrawContext context, List<ResultView> results) {
        if (results.size() == 1) {
            ResultView result = results.getFirst();
            int cx = panelX + rx(745);
            boolean rendered = PokemonPortraitRenderer.draw(context, result.speciesId(), cx, panelY + ry(610), rx(190));
            if (!rendered) drawCentered(context, "◆", cx, panelY + ry(470), tierColor(result.tier()));
            drawCentered(context, result.name(), cx, panelY + ry(665), 0xFFFFFFFF);
            drawCentered(context, result.tier() + " · NIVEL " + result.level() + (result.shiny() ? " · SHINY" : ""),
                    cx, panelY + ry(705), tierColor(result.tier()));
            return;
        }
        int columns = 5;
        for (int index = 0; index < Math.min(10, results.size()); index++) {
            ResultView result = results.get(index);
            int col = index % columns, row = index / columns;
            int cx = panelX + rx(390 + col * 145);
            int top = panelY + ry(275 + row * 245);
            context.fill(cx - rx(61), top, cx + rx(61), top + ry(195), 0xB0150D24);
            outline(context, cx - rx(61), top, rx(122), ry(195), tierColor(result.tier()));
            if (!PokemonPortraitRenderer.draw(context, result.speciesId(), cx, top + ry(125), rx(72)))
                drawCentered(context, "◆", cx, top + ry(65), tierColor(result.tier()));
            drawCentered(context, trim(result.name(), 14), cx, top + ry(145), 0xFFFFFFFF);
            drawCentered(context, "Nv." + result.level() + (result.shiny() ? " ✦" : ""), cx, top + ry(171), tierColor(result.tier()));
        }
    }

    private void drawEmptyStage(DrawContext context) {
        drawCentered(context, view.emi() ? "Usa tickets especiales de Emi" : "Usa tickets gacha normales",
                panelX + rx(745), panelY + ry(515), 0xFFFFFFFF);
        drawCentered(context, "El resultado y el pity los decide el servidor",
                panelX + rx(745), panelY + ry(555), 0xFFCAD8E8);
    }

    private boolean animating() {
        return revealStartedAt > 0L && System.currentTimeMillis() - revealStartedAt < REVEAL_MILLIS;
    }

    private void drawCentered(DrawContext context, String value, int x, int y, int color) {
        context.drawCenteredTextWithShadow(textRenderer, Text.literal(value == null ? "" : value), x, y, color);
    }

    private void outline(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x, y, x + w, y + 2, color); c.fill(x, y + h - 2, x + w, y + h, color);
        c.fill(x, y, x + 2, y + h, color); c.fill(x + w - 2, y, x + w, y + h, color);
    }

    private int tierColor(String tier) {
        return switch (tier == null ? "" : tier) {
            case "MYTHICAL", "SPECIAL" -> 0xFFFF7AD9;
            case "LEGENDARY" -> 0xFFFFC84A;
            case "EPIC" -> 0xFFC790FF;
            case "RARE" -> 0xFF5FC9FF;
            default -> 0xFFA8F0C6;
        };
    }

    private String trim(String value, int maximum) {
        if (value == null) return "";
        return value.length() <= maximum ? value : value.substring(0, maximum - 1) + "…";
    }

    private int rx(int value) { return Math.round(value * panelW / (float) REF_W); }
    private int ry(int value) { return Math.round(value * panelH / (float) REF_H); }

    @Override public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) { }
    @Override public void close() { if (client != null) client.setScreen(parent); }

    private static final class Hotspot extends ButtonWidget {
        private Hotspot(int x, int y, int width, int height, Text narration, PressAction action) {
            super(x, y, width, height, narration, action, DEFAULT_NARRATION_SUPPLIER);
        }
        @Override protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) { }
    }
}
