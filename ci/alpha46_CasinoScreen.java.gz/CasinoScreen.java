package com.emipokemon.client.casino;

import com.emipokemon.Emipokemon;
import com.emipokemon.casino.CasinoNetworking;
import com.google.gson.Gson;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

final class CasinoScreen extends Screen {
    private static final Gson GSON = new Gson();
    private static final Set<Integer> RED_NUMBERS = Set.of(1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36);
    private static final int[] ROULETTE_WHEEL = {
            0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26
    };
    private static final double TAU = Math.PI * 2.0D;
    private static final Identifier ROULETTE_HEADER = Identifier.of(Emipokemon.MOD_ID, "textures/gui/casino/roulette_header.png");
    private static final Identifier ROULETTE_LEFT_PANEL = Identifier.of(Emipokemon.MOD_ID, "textures/gui/casino/roulette_left_panel.png");
    private static final Identifier ROULETTE_SIDE_PANEL = Identifier.of(Emipokemon.MOD_ID, "textures/gui/casino/roulette_side_panel.png");
    private static final Identifier ROULETTE_WHEEL_OUTER = Identifier.of(Emipokemon.MOD_ID, "textures/gui/casino/roulette_wheel_outer.png");
    private static final Identifier ROULETTE_MEDALLION = Identifier.of(Emipokemon.MOD_ID, "textures/gui/casino/roulette_medallion.png");
    private static final int ROULETTE_HEADER_W = 1080;
    private static final int ROULETTE_HEADER_H = 76;
    private static final int ROULETTE_LEFT_W = 728;
    private static final int ROULETTE_LEFT_H = 572;
    private static final int ROULETTE_SIDE_W = 304;
    private static final int ROULETTE_SIDE_H = 572;
    private static final int ROULETTE_HEADER_TEX_W = 540;
    private static final int ROULETTE_HEADER_TEX_H = 38;
    private static final int ROULETTE_LEFT_TEX_W = 182;
    private static final int ROULETTE_LEFT_TEX_H = 143;
    private static final int ROULETTE_SIDE_TEX_W = 152;
    private static final int ROULETTE_SIDE_TEX_H = 286;

    private static final int BACKDROP = 0xD20A070B;
    private static final int PANEL = 0xFF17100F;
    private static final int PANEL_2 = 0xFF211715;
    private static final int FELT = 0xFF17472F;
    private static final int FELT_2 = 0xFF1C5A3A;
    private static final int GOLD = 0xFFFFD166;
    private static final int GOLD_DARK = 0xFF9A6E2A;
    private static final int RED = 0xFFB93636;
    private static final int BLACK = 0xFF171717;
    private static final int GREEN = 0xFF1A6B45;
    private static final int WHITE = 0xFFF7F0E4;
    private static final int MUTED = 0xFFCABEA9;
    private static final int LINE = 0xFF6B523B;
    private static final int CHIP = 0xFFFFC94D;

    private final Screen parent;
    private final CasinoNetworking.CasinoState state;
    private final String previousAmount;
    private final long openedAt = System.currentTimeMillis();

    private TextFieldWidget amountField;
    private final List<RouletteCell> rouletteCells = new ArrayList<>();
    private final List<QuickChipZone> quickChipZones = new ArrayList<>();

    private int panelX;
    private int panelY;
    private int panelW;
    private int panelH;
    private int gameX;
    private int gameW;
    private int sideX;
    private int sideW;
    private int contentTop;
    private int rouletteBoardY;
    private int rouletteCellW;
    private int rouletteCellH;
    private int wheelCx;
    private int wheelCy;
    private int wheelRadius;
    private int rouletteContentH;

    CasinoScreen(Screen parent, String json, String previousAmount) {
        super(Text.literal("Casino Emipokemon"));
        this.parent = parent;
        this.state = GSON.fromJson(json, CasinoNetworking.CasinoState.class);
        this.previousAmount = previousAmount;
    }

    Screen parentScreen() { return parent; }
    String amountText() { return amountField == null ? previousAmount : amountField.getText(); }

    @Override
    protected void init() {
        rouletteCells.clear();
        quickChipZones.clear();
        panelW = Math.min(1080, Math.max(620, width - 20));
        panelH = Math.min(660, Math.max(430, height - 20));
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;

        if (isRoulette()) {
            contentTop = panelY + 76;
            initRoulette();
        } else {
            contentTop = panelY + 68;
            addDrawableChild(new CasinoButtonWidget(panelX + panelW - 96, panelY + 20, 72, 22,
                    Text.literal("Cerrar"), this::close));
            initGeneric();
        }
    }

    private void initRoulette() {
        int gap = 8;
        rouletteContentH = Math.max(360, panelH - 84);
        int idealGameW = Math.round(rouletteContentH * (ROULETTE_LEFT_W / (float)ROULETTE_LEFT_H));
        int idealSideW = Math.round(rouletteContentH * (ROULETTE_SIDE_W / (float)ROULETTE_SIDE_H));
        int availableW = panelW - 24;
        float fit = Math.min(1.0F, availableW / (float)(idealGameW + gap + idealSideW));
        gameW = Math.round(idealGameW * fit);
        sideW = Math.round(idealSideW * fit);
        rouletteContentH = Math.round(rouletteContentH * fit);
        gameX = panelX + (panelW - gameW - gap - sideW) / 2;
        sideX = gameX + gameW + gap;

        int fieldX = sideX + sidePx(62);
        int fieldY = contentTop + sidePy(146);
        int fieldW = Math.max(76, sidePx(178));
        amountField = new TextFieldWidget(textRenderer, fieldX, fieldY, fieldW, Math.max(16, sidePy(25)), Text.literal("Cantidad"));
        amountField.setText(startAmount());
        amountField.setMaxLength(18);
        amountField.setDrawsBackground(false);
        amountField.setEditableColor(WHITE);
        amountField.setTextShadow(true);
        addDrawableChild(amountField);

        wheelCx = gameX + leftPx(405);
        wheelCy = contentTop + leftPy(152);
        wheelRadius = Math.max(82, leftPx(112));
        rouletteBoardY = contentTop + leftPy(292);
        buildRouletteCells();

        quickChipZones.add(new QuickChipZone(gameX + leftPx(272), contentTop + leftPy(528), 1, "MIN"));
        quickChipZones.add(new QuickChipZone(gameX + leftPx(374), contentTop + leftPy(528), 5, "x5"));
        quickChipZones.add(new QuickChipZone(gameX + leftPx(476), contentTop + leftPy(528), 10, "x10"));
    }

    private void buildRouletteCells() {
        int zeroX = gameX + leftPx(39);
        int zeroY = contentTop + leftPy(292);
        int zeroW = leftPx(59);
        int numberX = gameX + leftPx(98);
        int numberW = leftPx(551);
        int columnX = gameX + leftPx(649);
        int columnW = leftPx(50);
        int numbersBottom = contentTop + leftPy(404);

        rouletteCells.add(new RouletteCell(zeroX, zeroY, zeroW, numbersBottom - zeroY, "0", "number:0"));
        for (int column = 0; column < 12; column++) {
            int x1 = numberX + Math.round(numberW * (column / 12.0F));
            int x2 = numberX + Math.round(numberW * ((column + 1) / 12.0F));
            int base = (column + 1) * 3;
            for (int row = 0; row < 3; row++) {
                int y1 = zeroY + Math.round((numbersBottom - zeroY) * (row / 3.0F));
                int y2 = zeroY + Math.round((numbersBottom - zeroY) * ((row + 1) / 3.0F));
                int number = base - row;
                rouletteCells.add(new RouletteCell(x1, y1, x2 - x1, y2 - y1, Integer.toString(number), "number:" + number));
            }
        }
        for (int row = 0; row < 3; row++) {
            int y1 = zeroY + Math.round((numbersBottom - zeroY) * (row / 3.0F));
            int y2 = zeroY + Math.round((numbersBottom - zeroY) * ((row + 1) / 3.0F));
            rouletteCells.add(new RouletteCell(columnX, y1, columnW, y2 - y1, "2:1", "column" + (3 - row)));
        }

        int dozenX = gameX + leftPx(92);
        int dozenY = contentTop + leftPy(405);
        int dozenW = leftPx(557);
        int dozenH = Math.max(18, leftPy(35));
        for (int i = 0; i < 3; i++) {
            int x1 = dozenX + Math.round(dozenW * (i / 3.0F));
            int x2 = dozenX + Math.round(dozenW * ((i + 1) / 3.0F));
            rouletteCells.add(new RouletteCell(x1, dozenY, x2 - x1, dozenH, (i + 1) + "ª DOCENA", "dozen" + (i + 1)));
        }

        int outsideY = contentTop + leftPy(441);
        int outsideH = Math.max(18, leftPy(36));
        String[] labels = {"1–18", "PAR", "ROJO", "NEGRO", "IMPAR", "19–36"};
        String[] actions = {"low", "even", "red", "black", "odd", "high"};
        for (int i = 0; i < 6; i++) {
            int x1 = dozenX + Math.round(dozenW * (i / 6.0F));
            int x2 = dozenX + Math.round(dozenW * ((i + 1) / 6.0F));
            rouletteCells.add(new RouletteCell(x1, outsideY, x2 - x1, outsideH, labels[i], actions[i]));
        }
    }

    private void initGeneric() {
        sideW = Math.min(410, Math.max(290, panelW / 2 - 30));
        gameX = panelX + 24;
        gameW = sideW;
        sideX = panelX + panelW - sideW - 24;

        int inputY = contentTop + 70;
        amountField = new TextFieldWidget(textRenderer, gameX + 14, inputY, gameW - 28, 22, Text.literal("Cantidad"));
        amountField.setText(startAmount());
        amountField.setMaxLength(18);
        addDrawableChild(amountField);

        int quickY = inputY + 30;
        int qGap = 5;
        int qW = (gameW - 28 - qGap * 2) / 3;
        addDrawableChild(new CasinoButtonWidget(gameX + 14, quickY, qW, 20, Text.literal("Mínimo"), () -> setQuickAmount(1)));
        addDrawableChild(new CasinoButtonWidget(gameX + 14 + qW + qGap, quickY, qW, 20, Text.literal("x5"), () -> setQuickAmount(5)));
        addDrawableChild(new CasinoButtonWidget(gameX + 14 + (qW + qGap) * 2, quickY, qW, 20, Text.literal("x10"), () -> setQuickAmount(10)));

        List<Action> actions = actions();
        int actionsY = quickY + 36;
        int actionGap = 8;
        int buttonW = (gameW - 28 - actionGap) / 2;
        for (int i = 0; i < actions.size(); i++) {
            Action action = actions.get(i);
            int col = i % 2;
            int row = i / 2;
            addDrawableChild(new CasinoButtonWidget(gameX + 14 + col * (buttonW + actionGap), actionsY + row * 29,
                    buttonW, 22, Text.literal(action.label), () -> send(action.action)));
        }
    }

    private String startAmount() {
        return previousAmount == null || previousAmount.isBlank()
                ? Long.toString(Math.max(1L, state.minimumBet())) : previousAmount;
    }

    private void setQuickAmount(int multiplier) {
        long base = Math.max(1L, state.minimumBet());
        long amount = base > Long.MAX_VALUE / multiplier ? Long.MAX_VALUE : base * multiplier;
        if (amountField != null) amountField.setText(Long.toString(amount));
    }

    private boolean isRoulette() { return "roulette".equals(state.game()); }
    private boolean isBettingPhase() { return "idle".equals(state.phase()) || "betting".equals(state.phase()); }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, BACKDROP);
        context.fill(panelX - 4, panelY + 5, panelX + panelW + 4, panelY + panelH + 5, 0x99000000);

        if (isRoulette()) {
            drawAsset(context, ROULETTE_HEADER, panelX, panelY, panelW, 76, ROULETTE_HEADER_TEX_W, ROULETTE_HEADER_TEX_H);
            drawAsset(context, ROULETTE_LEFT_PANEL, gameX, contentTop, gameW, rouletteContentH, ROULETTE_LEFT_TEX_W, ROULETTE_LEFT_TEX_H);
            drawAsset(context, ROULETTE_SIDE_PANEL, sideX, contentTop, sideW, rouletteContentH, ROULETTE_SIDE_TEX_W, ROULETTE_SIDE_TEX_H);
            String balance = state.balance() + " Michicoins";
            int balanceX = panelX + Math.round(panelW * 0.790F);
            context.drawTextWithShadow(textRenderer, Text.literal(balance), balanceX, panelY + 34, 0xFFFFD75A);
            renderRoulette(context, mouseX, mouseY);
        } else {
            context.fill(panelX, panelY, panelX + panelW, panelY + panelH, PANEL);
            outline(context, panelX, panelY, panelW, panelH, GOLD_DARK);
            outline(context, panelX + 2, panelY + 2, panelW - 4, panelH - 4, LINE);
            context.fill(panelX, panelY, panelX + panelW, panelY + 5, GOLD_DARK);
            context.fill(panelX, panelY + 5, panelX + panelW, panelY + 8, GOLD);
            String title = safe(state.title(), "Casino Emipokemon");
            context.drawTextWithShadow(textRenderer, Text.literal(title), panelX + 24, panelY + 20, WHITE);
            context.drawTextWithShadow(textRenderer, Text.literal("MESA MULTIJUGADOR · SERVIDOR AUTORITATIVO"), panelX + 24, panelY + 40, 0xFF9FD8AF);
            String balance = state.balance() + " Michicoins";
            context.drawTextWithShadow(textRenderer, Text.literal(balance), panelX + panelW - 122 - textRenderer.getWidth(balance), panelY + 34, GOLD);
            renderGeneric(context);
        }
        super.render(context, mouseX, mouseY, delta);
    }

    private void renderRoulette(DrawContext context, int mouseX, int mouseY) {
        drawRouletteWheel(context);
        drawRecentResults(context);

        String selected = selectedAction();
        for (RouletteCell cell : rouletteCells) drawRouletteCell(context, cell, mouseX, mouseY, selected);
        drawQuickChipControls(context, mouseX, mouseY);

        // Dynamic right-panel data placed over the static casino chrome asset.
        int roundY = contentTop + sidePy(47);
        drawBadge(context, sideX + sidePx(27), roundY, phaseLabel(), isBettingPhase() ? 0xFF83F0A8 : GOLD);
        String timer = timerOnly();
        if (!timer.isBlank()) {
            context.drawTextWithShadow(textRenderer, Text.literal(timer), sideX + sidePx(188), roundY + 5, 0xFFFFE59A);
        }

        String selectedAmount = selectedBetAmount();
        String own = selected.isBlank() ? "Aún no has apostado" : betLabel(selected) + (selectedAmount.isBlank() ? "" : " · " + selectedAmount);
        drawWrapped(context, own, sideX + sidePx(35), contentTop + sidePy(266), sidePx(235), WHITE, contentTop + sidePy(309));
        if (selected.isBlank()) {
            context.drawTextWithShadow(textRenderer, Text.literal("Selecciona una casilla en el tapete"), sideX + sidePx(35), contentTop + sidePy(290), MUTED);
        }

        List<String> players = state.players() == null ? List.of() : state.players();
        String playerCount = Integer.toString(players.size());
        context.drawTextWithShadow(textRenderer, Text.literal(playerCount), sideX + sideW - sidePx(31), contentTop + sidePy(331), 0xFFFFD45A);
        drawPlayers(context, contentTop + sidePy(365), contentTop + sidePy(449));

        drawWrapped(context, safe(state.tableState(), "Mesa lista para una nueva ronda."), sideX + sidePx(33), contentTop + sidePy(507), sidePx(222), WHITE, contentTop + sidePy(548));
    }

    private void drawRouletteWheel(DrawContext context) {
        int outerRadius = leftPx(143);
        drawCircle(context, wheelCx, wheelCy + leftPy(6), outerRadius, 0x55000000);
        drawCircle(context, wheelCx, wheelCy, wheelRadius + leftPx(12), 0xFF4B2A1B);
        drawCircle(context, wheelCx, wheelCy, wheelRadius + leftPx(5), 0xFF0E2B20);

        double rotation = rouletteWheelRotation();
        for (int i = 0; i < ROULETTE_WHEEL.length; i++) {
            int number = ROULETTE_WHEEL[i];
            double angle = rotation + TAU * i / ROULETTE_WHEEL.length - Math.PI / 2.0D;
            int px = wheelCx + (int)Math.round(Math.cos(angle) * wheelRadius);
            int py = wheelCy + (int)Math.round(Math.sin(angle) * wheelRadius);
            int color = number == 0 ? 0xFF07854D : RED_NUMBERS.contains(number) ? 0xFFD92735 : 0xFF171318;
            int tileW = Math.max(10, leftPx(15));
            int tileH = Math.max(8, leftPy(13));
            context.fill(px - tileW / 2, py - tileH / 2, px + (tileW + 1) / 2, py + (tileH + 1) / 2, color);
            outline(context, px - tileW / 2, py - tileH / 2, tileW, tileH, 0xFFD59A33);
            String label = Integer.toString(number);
            context.getMatrices().push();
            context.getMatrices().translate(px, py, 0.0F);
            context.getMatrices().scale(0.72F, 0.72F, 1.0F);
            context.drawTextWithShadow(textRenderer, Text.literal(label), -textRenderer.getWidth(label) / 2, -4, WHITE);
            context.getMatrices().pop();
        }

        int trimSize = outerRadius * 2;
        drawAsset(context, ROULETTE_WHEEL_OUTER, wheelCx - outerRadius, wheelCy - outerRadius, trimSize, trimSize, 128, 128);

        int medSize = leftPx(91);
        drawAsset(context, ROULETTE_MEDALLION, wheelCx - medSize / 2, wheelCy - medSize / 2, medSize, medSize, 64, 64);

        long elapsed = Math.max(0L, System.currentTimeMillis() - openedAt);
        int result = rouletteResultNumber();
        boolean settled = "result".equals(state.phase()) && result >= 0 && elapsed >= 1800L;
        double ballAngle = settled ? -Math.PI / 2.0D : -rouletteWheelRotation() * 1.31D + 0.45D;
        int ballRadius = wheelRadius + leftPx(19);
        int bx = wheelCx + (int)Math.round(Math.cos(ballAngle) * ballRadius);
        int by = wheelCy + (int)Math.round(Math.sin(ballAngle) * ballRadius);
        drawCircle(context, bx, by, Math.max(3, leftPx(5)), WHITE);
        drawCircleOutline(context, bx, by, Math.max(3, leftPx(5)), 0xFF886C4C);
    }

    private double rouletteWheelRotation() {
        long elapsed = Math.max(0L, System.currentTimeMillis() - openedAt);
        int result = rouletteResultNumber();
        if ("result".equals(state.phase()) && result >= 0) {
            int index = 0;
            for (int i = 0; i < ROULETTE_WHEEL.length; i++) if (ROULETTE_WHEEL[i] == result) { index = i; break; }
            double t = Math.min(1.0D, elapsed / 1800.0D);
            double eased = 1.0D - Math.pow(1.0D - t, 3.0D);
            double target = -TAU * index / ROULETTE_WHEEL.length;
            return (TAU * 5.0D + target) * eased;
        }
        return elapsed * 0.00115D;
    }

    private int rouletteResultNumber() {
        List<Integer> recent = state.recentResults();
        if ("result".equals(state.phase()) && recent != null && !recent.isEmpty()) return recent.getFirst();
        String value = safe(state.tableState(), "");
        int marker = value.indexOf("salió ");
        if (marker < 0) marker = value.indexOf("salio ");
        if (marker < 0) return -1;
        int start = marker + 6;
        while (start < value.length() && !Character.isDigit(value.charAt(start))) start++;
        int end = start;
        while (end < value.length() && Character.isDigit(value.charAt(end))) end++;
        if (start >= end) return -1;
        try { return Integer.parseInt(value.substring(start, end)); }
        catch (NumberFormatException ignored) { return -1; }
    }

    private void drawRouletteCell(DrawContext context, RouletteCell cell, int mouseX, int mouseY, String selected) {
        if (cell.action.equals(selected)) {
            outline(context, cell.x, cell.y, cell.w, cell.h, 0xFFFFD75A);
            if (cell.w > 5 && cell.h > 5) outline(context, cell.x + 2, cell.y + 2, cell.w - 4, cell.h - 4, 0xFFFFF1A8);
            drawChip(context, cell.x + cell.w - Math.max(6, leftPx(8)), cell.y + Math.max(7, leftPy(9)));
        } else if (isBettingPhase() && cell.contains(mouseX, mouseY)) {
            outline(context, cell.x, cell.y, cell.w, cell.h, WHITE);
            if (cell.w > 5 && cell.h > 5) outline(context, cell.x + 2, cell.y + 2, cell.w - 4, cell.h - 4, 0xAAFFFFCC);
        }
    }

    private int rouletteCellColor(String action) {
        if (action.startsWith("number:")) {
            int number = Integer.parseInt(action.substring(7));
            if (number == 0) return GREEN;
            return RED_NUMBERS.contains(number) ? RED : BLACK;
        }
        return switch (action) {
            case "red" -> RED;
            case "black" -> BLACK;
            case "column1", "column2", "column3", "dozen1", "dozen2", "dozen3" -> FELT_2;
            default -> FELT;
        };
    }

    private void drawChip(DrawContext context, int x, int y) {
        drawCasinoChip(context, x, y, 6, 0xFFB93636);
    }

    private void drawRecentResults(DrawContext context) {
        List<Integer> recent = state.recentResults() == null ? List.of() : state.recentResults();
        int box = Math.max(18, leftPx(25));
        int gap = Math.max(2, leftPx(4));
        int y = contentTop + leftPy(88);
        int total = Math.min(5, recent.size()) * box + Math.max(0, Math.min(5, recent.size()) - 1) * gap;
        int center = gameX + leftPx(638);
        if (recent.isEmpty()) {
            context.drawCenteredTextWithShadow(textRenderer, Text.literal("—"), center, y + 7, MUTED);
            return;
        }
        int startX = center - total / 2;
        for (int i = 0; i < Math.min(5, recent.size()); i++) {
            int number = recent.get(i);
            int bx = startX + i * (box + gap);
            int color = number == 0 ? 0xFF07854D : RED_NUMBERS.contains(number) ? 0xFFD92735 : 0xFF171318;
            drawCircle(context, bx + box / 2, y + box / 2, box / 2, color);
            drawCircleOutline(context, bx + box / 2, y + box / 2, box / 2, i == 0 ? GOLD : 0xFFD39A39);
            String label = Integer.toString(number);
            context.drawTextWithShadow(textRenderer, Text.literal(label), bx + (box - textRenderer.getWidth(label)) / 2, y + (box - 8) / 2, WHITE);
        }
    }

    private void drawQuickChipControls(DrawContext context, int mouseX, int mouseY) {
        String current = amountField == null ? "" : amountField.getText().strip();
        for (QuickChipZone chip : quickChipZones) {
            long base = Math.max(1L, state.minimumBet());
            long value = base > Long.MAX_VALUE / chip.multiplier ? Long.MAX_VALUE : base * chip.multiplier;
            boolean selected = current.equals(Long.toString(value));
            boolean hover = chip.contains(mouseX, mouseY);
            if (selected || hover) drawCircleOutline(context, chip.x, chip.y, leftPx(selected ? 31 : 29), selected ? GOLD : WHITE);
        }
    }

    private void drawPlayers(DrawContext context, int y, int maxY) {
        List<String> players = state.players() == null ? List.of() : state.players();
        if (players.isEmpty()) {
            context.drawTextWithShadow(textRenderer, Text.literal("Esperando apuestas…"), sideX + sidePx(34), y, MUTED);
            return;
        }
        int shown = 0;
        for (String player : players) {
            if (y + 14 > maxY || shown >= 5) break;
            drawCircle(context, sideX + sidePx(29), y + 5, Math.max(3, sidePx(5)), 0xFF485078);
            String clipped = textRenderer.trimToWidth(player, sideW - sidePx(58));
            context.drawTextWithShadow(textRenderer, Text.literal(clipped), sideX + sidePx(41), y + 1, WHITE);
            y += Math.max(13, sidePy(18));
            shown++;
        }
        if (players.size() > shown && y <= maxY) {
            context.drawTextWithShadow(textRenderer, Text.literal("+" + (players.size() - shown) + " más"), sideX + sidePx(41), y, MUTED);
        }
    }

    private void drawInfoBox(DrawContext context, int x, int y, int w, int h, String title) {
        drawFramedPanel(context, x, y, w, h, PANEL_2, GOLD_DARK);
        context.fill(x + 1, y + 1, x + w - 1, y + 22, 0xFF2A1B16);
        context.fill(x + 1, y + 21, x + w - 1, y + 22, LINE);
        context.drawTextWithShadow(textRenderer, Text.literal(title), x + 14, y + 7, GOLD);
    }

    private void drawFramedPanel(DrawContext context, int x, int y, int w, int h, int fill, int border) {
        context.fill(x, y, x + w, y + h, fill);
        outline(context, x, y, w, h, border);
        if (w > 4 && h > 4) outline(context, x + 2, y + 2, w - 4, h - 4, LINE);
    }

    private void drawCaptureBall(DrawContext context, int cx, int cy, int radius) {
        for (int dy = -radius; dy <= radius; dy++) {
            int dx = (int)Math.floor(Math.sqrt(Math.max(0, radius * radius - dy * dy)));
            int color = dy < 0 ? RED : WHITE;
            context.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, color);
        }
        context.fill(cx - radius, cy - 1, cx + radius + 1, cy + 2, BLACK);
        drawCircle(context, cx, cy, Math.max(2, radius / 3), BLACK);
        drawCircle(context, cx, cy, Math.max(1, radius / 5), WHITE);
        drawCircleOutline(context, cx, cy, radius, GOLD_DARK);
    }

    private void drawCasinoChip(DrawContext context, int cx, int cy, int radius, int accent) {
        drawCircle(context, cx, cy, radius, 0xFF4A352A);
        drawCircle(context, cx, cy, Math.max(1, radius - 2), accent);
        drawCircle(context, cx, cy, Math.max(1, radius - 6), WHITE);
        context.fill(cx - radius + 2, cy - 1, cx + radius - 1, cy + 2, accent);
        context.fill(cx - 1, cy - radius + 2, cx + 2, cy + radius - 1, accent);
    }

    private void drawCoin(DrawContext context, int cx, int cy, int radius) {
        drawCircle(context, cx, cy, radius, GOLD_DARK);
        drawCircle(context, cx, cy, Math.max(1, radius - 1), GOLD);
        if (radius >= 4) context.fill(cx - 1, cy - 2, cx + 2, cy + 3, GOLD_DARK);
    }

    private void drawCoinStack(DrawContext context, int x, int y) {
        drawCoin(context, x - 8, y + 4, 6);
        drawCoin(context, x, y + 8, 6);
        drawCoin(context, x + 8, y + 4, 6);
        drawCoin(context, x, y - 1, 6);
    }

    private void drawCircleOutline(DrawContext context, int cx, int cy, int radius, int color) {
        int inner = Math.max(0, radius - 1);
        for (int dy = -radius; dy <= radius; dy++) {
            int outerDx = (int)Math.floor(Math.sqrt(Math.max(0, radius * radius - dy * dy)));
            int innerDx = Math.abs(dy) > inner ? -1 : (int)Math.floor(Math.sqrt(Math.max(0, inner * inner - dy * dy)));
            if (innerDx < 0) context.fill(cx - outerDx, cy + dy, cx + outerDx + 1, cy + dy + 1, color);
            else {
                context.fill(cx - outerDx, cy + dy, cx - innerDx, cy + dy + 1, color);
                context.fill(cx + innerDx + 1, cy + dy, cx + outerDx + 1, cy + dy + 1, color);
            }
        }
    }

    private void renderGeneric(DrawContext context) {
        context.fill(gameX, contentTop, gameX + gameW, panelY + panelH - 24, PANEL_2);
        context.fill(sideX, contentTop, sideX + sideW, panelY + panelH - 24, PANEL_2);
        outline(context, gameX, contentTop, gameW, panelY + panelH - 24 - contentTop, LINE);
        outline(context, sideX, contentTop, sideW, panelY + panelH - 24 - contentTop, LINE);

        context.drawTextWithShadow(textRenderer, Text.literal("APUESTA / ACCIONES"), gameX + 14, contentTop + 14, GOLD);
        context.drawTextWithShadow(textRenderer, Text.literal("Cantidad"), gameX + 14, contentTop + 54, MUTED);
        context.drawTextWithShadow(textRenderer, Text.literal("ESTADO DE LA PARTIDA"), sideX + 14, contentTop + 14, GOLD);
        drawBadge(context, sideX + 14, contentTop + 34, phaseLabel() + timerLabel(), 0xFF8DE6B5);

        int y = contentTop + 68;
        context.drawTextWithShadow(textRenderer, Text.literal("Mesa"), sideX + 14, y, MUTED);
        y = drawWrapped(context, safe(state.tableState(), "Sin datos"), sideX + 14, y + 15, sideW - 28, WHITE, contentTop + 154);
        y = Math.max(contentTop + 164, y + 8);
        context.drawTextWithShadow(textRenderer, Text.literal("Tu estado"), sideX + 14, y, GOLD);
        y = drawWrapped(context, safe(state.privateState(), "Sin acción pendiente"), sideX + 14, y + 15, sideW - 28, WHITE, contentTop + 238);
        y = Math.max(contentTop + 250, y + 8);
        context.drawTextWithShadow(textRenderer, Text.literal("Jugadores"), sideX + 14, y, MUTED);
        y += 16;
        List<String> players = state.players() == null ? List.of() : state.players();
        if (players.isEmpty()) context.drawTextWithShadow(textRenderer, Text.literal("—"), sideX + 14, y, MUTED);
        else for (String player : players) {
            if (y > panelY + panelH - 105) break;
            context.drawTextWithShadow(textRenderer, Text.literal("• " + player), sideX + 14, y, WHITE);
            y += 14;
        }

        int messageY = panelY + panelH - 84;
        context.fill(panelX + 24, messageY, panelX + panelW - 24, panelY + panelH - 30, 0xFF100B0A);
        outline(context, panelX + 24, messageY, panelW - 48, panelY + panelH - 30 - messageY, LINE);
        drawWrapped(context, safe(state.message(), "Listo"), panelX + 34, messageY + 12, panelW - 68, WHITE, panelY + panelH - 34);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;
        if (button == 0 && isRoulette()) {
            if (inside(mouseX, mouseY, panelX + Math.round(panelW * 0.884F), panelY + 29, Math.round(panelW * 0.092F), 37)) {
                close();
                return true;
            }
            int qy = contentTop + sidePy(184);
            int qh = sidePy(29);
            if (inside(mouseX, mouseY, sideX + sidePx(27), qy, sidePx(81), qh)) { setQuickAmount(1); return true; }
            if (inside(mouseX, mouseY, sideX + sidePx(111), qy, sidePx(85), qh)) { setQuickAmount(5); return true; }
            if (inside(mouseX, mouseY, sideX + sidePx(199), qy, sidePx(81), qh)) { setQuickAmount(10); return true; }
            for (QuickChipZone chip : quickChipZones) {
                if (chip.contains(mouseX, mouseY)) {
                    setQuickAmount(chip.multiplier);
                    return true;
                }
            }
            if (isBettingPhase()) {
                for (RouletteCell cell : rouletteCells) {
                    if (cell.contains(mouseX, mouseY)) {
                        send(cell.action);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private List<Action> actions() {
        List<Action> result = new ArrayList<>();
        String game = safe(state.game(), "");
        String phase = safe(state.phase(), "single");
        if ("slot".equals(game)) {
            result.add(new Action("Girar", "spin"));
        } else if ("chip_exchange".equals(game)) {
            result.add(new Action("Comprar fichas", "buy"));
            result.add(new Action("Canjear fichas", "sell"));
        } else if ("ticket_exchange".equals(game)) {
            result.add(new Action("Comprar ticket", "buy_ticket"));
        } else if ("dice".equals(game) && isBettingPhase()) {
            result.add(new Action("Menos de 7", "under7"));
            result.add(new Action("Más de 7", "over7"));
            result.add(new Action("Exactamente 7", "exact7"));
        } else if ("blackjack".equals(game)) {
            if (isBettingPhase()) result.add(new Action("Unirse a la mano", "join"));
            else if ("blackjack".equals(phase)) {
                result.add(new Action("Pedir", "hit"));
                result.add(new Action("Plantarse", "stand"));
            }
        } else if ("poker".equals(game)) {
            if (isBettingPhase()) result.add(new Action("Entrar al bote", "join"));
            else if (phase.startsWith("poker_")) result.add(new Action("Retirarse", "fold"));
        }
        return result;
    }

    private void send(String action) {
        long amount;
        try { amount = Long.parseLong(amountField == null ? "0" : amountField.getText().strip()); }
        catch (Exception ignored) { amount = 0L; }
        ClientPlayNetworking.send(new CasinoNetworking.CasinoActionPayload(state.blockPos(), action, amount));
    }

    private String selectedAction() {
        String value = safe(state.privateState(), "");
        String marker = "Tu apuesta: ";
        int start = value.indexOf(marker);
        if (start < 0) return "";
        start += marker.length();
        int end = value.indexOf(" ·", start);
        if (end < 0) end = value.length();
        return value.substring(start, end).strip();
    }

    private String selectedBetAmount() {
        String value = safe(state.privateState(), "");
        String marker = " · ";
        int start = value.indexOf(marker);
        if (start < 0) return "";
        start += marker.length();
        int end = value.indexOf(" Michicoins", start);
        if (end < 0) return "";
        String amount = value.substring(start, end).strip();
        return amount.chars().allMatch(Character::isDigit) ? amount : "";
    }

    private String betLabel(String action) {
        if (action.startsWith("number:")) return "Número exacto " + action.substring(7);
        return switch (action) {
            case "red" -> "Rojo";
            case "black" -> "Negro";
            case "even" -> "Par";
            case "odd" -> "Impar";
            case "low" -> "1–18";
            case "high" -> "19–36";
            case "dozen1" -> "Primera docena";
            case "dozen2" -> "Segunda docena";
            case "dozen3" -> "Tercera docena";
            case "column1" -> "Columna 1 · 2:1";
            case "column2" -> "Columna 2 · 2:1";
            case "column3" -> "Columna 3 · 2:1";
            default -> action;
        };
    }

    private String phaseLabel() {
        return switch (safe(state.phase(), "single")) {
            case "idle" -> "Mesa lista";
            case "betting" -> "Apuestas abiertas";
            case "blackjack" -> "Blackjack en juego";
            case "poker_flop" -> "Póker · Flop";
            case "poker_turn" -> "Póker · Turn";
            case "poker_river" -> "Póker · River";
            case "result" -> "Resultado";
            default -> "Operación individual";
        };
    }

    private String timerLabel() {
        if (state.deadlineMillis() <= 0L) return "";
        long left = Math.max(0L, (state.deadlineMillis() - System.currentTimeMillis() + 999L) / 1000L);
        return " · " + left + " s";
    }

    private void drawBadge(DrawContext context, int x, int y, String text, int color) {
        int w = textRenderer.getWidth(text) + 14;
        context.fill(x, y, x + w, y + 18, 0xFF0F0B0A);
        outline(context, x, y, w, 18, LINE);
        context.drawTextWithShadow(textRenderer, Text.literal(text), x + 7, y + 5, color);
    }

    private int drawWrapped(DrawContext context, String value, int x, int y, int width, int color, int maxY) {
        if (value == null || value.isBlank()) return y;
        for (var line : textRenderer.wrapLines(Text.literal(value), width)) {
            if (y > maxY) break;
            context.drawTextWithShadow(textRenderer, line, x, y, color);
            y += 13;
        }
        return y;
    }

    private void drawCircle(DrawContext context, int cx, int cy, int radius, int color) {
        for (int dy = -radius; dy <= radius; dy++) {
            int dx = (int)Math.floor(Math.sqrt(Math.max(0, radius * radius - dy * dy)));
            context.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, color);
        }
    }

    private void outline(DrawContext context, int x, int y, int w, int h, int color) {
        context.fill(x, y, x + w, y + 1, color);
        context.fill(x, y + h - 1, x + w, y + h, color);
        context.fill(x, y, x + 1, y + h, color);
        context.fill(x + w - 1, y, x + w, y + h, color);
    }

    private int leftPx(int px) { return Math.max(1, Math.round(px * gameW / (float)ROULETTE_LEFT_W)); }
    private int leftPy(int py) { return Math.max(1, Math.round(py * rouletteContentH / (float)ROULETTE_LEFT_H)); }
    private int sidePx(int px) { return Math.max(1, Math.round(px * sideW / (float)ROULETTE_SIDE_W)); }
    private int sidePy(int py) { return Math.max(1, Math.round(py * rouletteContentH / (float)ROULETTE_SIDE_H)); }

    private void drawAsset(DrawContext context, Identifier texture, int x, int y, int w, int h, int textureW, int textureH) {
        context.drawTexture(texture, x, y, w, h, 0.0F, 0.0F, textureW, textureH, textureW, textureH);
    }

    private boolean inside(double mouseX, double mouseY, int x, int y, int w, int h) {
        return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
    }

    private String timerOnly() {
        if (state.deadlineMillis() <= 0L) return "";
        long left = Math.max(0L, (state.deadlineMillis() - System.currentTimeMillis() + 999L) / 1000L);
        return String.format("%02d:%02d", left / 60L, left % 60L);
    }

    private static String safe(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // Deliberately empty: the casino draws its own dim backdrop in render().
        // Allowing Screen.renderBackground() here re-applies Cobbleverse/Minecraft blur
        // over the casino UI and makes text, roulette numbers and widgets out of focus.
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() { if (client != null) client.setScreen(parent); }

    private record Action(String label, String action) { }
    private record QuickChipZone(int x, int y, int multiplier, String label) {
        boolean contains(double mouseX, double mouseY) {
            int dx = (int)Math.round(mouseX) - x;
            int dy = (int)Math.round(mouseY) - y;
            return dx * dx + dy * dy <= 34 * 34;
        }
    }
    private record RouletteCell(int x, int y, int w, int h, String label, String action) {
        boolean contains(double mouseX, double mouseY) {
            return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
        }
    }
}
