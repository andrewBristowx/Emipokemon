package com.emipokemon.progress;

import java.util.Locale;
import java.util.Set;

/** Canonical LuckPerms groups configured on the Emipokemon server. */
public final class RankGroups {
    public static final String DEFAULT = "default";
    public static final String BASIC = "michiba";
    public static final String VIP = "michivip";
    public static final String DONATOR = "michidonador";
    public static final String MODERATOR = "michimod";
    public static final String OWNERS = "michidueñas";

    public static final Set<String> ALL = Set.of(DEFAULT, BASIC, VIP, DONATOR, MODERATOR, OWNERS);
    public static final Set<String> SUPPORTERS = Set.of(VIP, DONATOR);
    public static final Set<String> STAFF = Set.of(MODERATOR, OWNERS);
    public static final Set<String> PREMIUM = Set.of(VIP, DONATOR, MODERATOR, OWNERS);

    private RankGroups() { }

    public static String normalize(String value) {
        return value == null ? "" : value.strip().toLowerCase(Locale.ROOT);
    }
}
