package com.emipokemon.client.render;

import com.emipokemon.Emipokemon;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import org.joml.Quaternionf;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

/**
 * Bridges Yarn's Identifier to Cobblemon's Mojmap ResourceLocation signature.
 * Cobblemon 1.7.3 needs the concrete no-arg FloatingState and its 16-argument overload.
 */
public final class PokemonPortraitRenderer {
    private static volatile Method drawMethod;
    private static volatile Constructor<?> stateConstructor;
    private static volatile Object profilePose;
    private static volatile boolean lookupFailed;
    private static volatile boolean failureLogged;

    private PokemonPortraitRenderer() { }

    public static boolean draw(DrawContext context, String speciesId, int centerX, int bottomY, int requestedSize) {
        boolean pushed = false;
        try {
            Method draw = resolveMethod();
            if (draw == null) return false;
            Identifier species = normalizeSpeciesId(speciesId);
            if (species == null) return false;
            Object poseState = stateConstructor.newInstance();
            float outerScale = Math.max(0.55F, requestedSize / 42.0F);
            context.getMatrices().push();
            pushed = true;
            context.getMatrices().translate(centerX, bottomY, 170.0F);
            context.getMatrices().scale(outerScale, outerScale, outerScale);
            if (draw.getParameterCount() == 16) {
                draw.invoke(null, species, context.getMatrices(), new Quaternionf(), profilePose, poseState,
                        0.0F, 20.0F, true, false, false,
                        1.0F, 1.0F, 1.0F, 1.0F, 0.0F, 0.0F);
            } else {
                // Compatibility with packs that expose Cobblemon's shorter portrait overload.
                draw.invoke(null, species, context.getMatrices(), new Quaternionf(), profilePose, poseState,
                        0.0F, 20.0F, true, false, 0.0F, 0.0F, 0.0F, 0.0F);
            }
            context.getMatrices().pop();
            return true;
        } catch (Throwable exception) {
            if (pushed) try { context.getMatrices().pop(); } catch (Throwable ignored) { }
            if (!failureLogged) {
                failureLogged = true;
                Emipokemon.LOGGER.warn("Could not render a Cobblemon portrait; the fallback icon will be used", exception);
            }
            return false;
        }
    }

    /** Cobblemon catalogs commonly store bare paths (for example "deoxys"). */
    private static Identifier normalizeSpeciesId(String speciesId) {
        if (speciesId == null || speciesId.isBlank()) return null;
        String normalized = speciesId.strip().toLowerCase(java.util.Locale.ROOT);
        return Identifier.tryParse(normalized.indexOf(':') >= 0 ? normalized : "cobblemon:" + normalized);
    }

    private static Method resolveMethod() throws Exception {
        if (drawMethod != null || lookupFailed) return drawMethod;
        synchronized (PokemonPortraitRenderer.class) {
            if (drawMethod != null || lookupFailed) return drawMethod;
            Class<?> floatingState = Class.forName(
                    "com.cobblemon.mod.common.client.render.models.blockbench.FloatingState");
            stateConstructor = floatingState.getDeclaredConstructor();
            stateConstructor.setAccessible(true);
            Class<?> poseTypeClass = Class.forName("com.cobblemon.mod.common.entity.PoseType");
            @SuppressWarnings({"unchecked", "rawtypes"})
            Object profile = Enum.valueOf((Class) poseTypeClass.asSubclass(Enum.class), "PROFILE");
            Method shorter = null;
            Class<?> utilities = Class.forName("com.cobblemon.mod.common.client.gui.PokemonGuiUtilsKt");
            for (Method method : utilities.getMethods()) {
                if (!method.getName().equals("drawProfilePokemon")) continue;
                if (method.getParameterCount() == 16) { drawMethod = method; break; }
                if (method.getParameterCount() == 13) shorter = method;
            }
            if (drawMethod == null) drawMethod = shorter;
            profilePose = profile;
            if (drawMethod == null) lookupFailed = true;
            return drawMethod;
        }
    }
}
