package com.emipokemon.gacha;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.junit.jupiter.api.Test;

import javax.imageio.ImageIO;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

final class Alpha66GachaKitsAndTextureRegressionTest {
    private static String source(String path) throws Exception { return Files.readString(Path.of("src", path)); }

    @Test void gachaUiSupportsServerValidatedOneAndTenPulls() throws Exception {
        String server = source("main/java/com/emipokemon/gacha/GachaNetworking.java");
        String screen = source("client/java/com/emipokemon/client/gacha/GachaScreen.java");
        assertTrue(server.contains("count != 1 && count != 10"));
        assertTrue(server.contains("squaredDistanceTo"));
        assertTrue(server.contains("pullWithCurrencyOverride"));
        assertTrue(server.contains("GachaProgress progress"));
        assertTrue(screen.contains("TIRAR ×1"));
        assertTrue(screen.contains("TIRAR ×10"));
        assertTrue(screen.contains("PITY LEGENDARIO"));
        assertTrue(screen.contains("PokemonPortraitRenderer.draw"));
    }

    @Test void gachaKeepsBothBackgroundsAndDoesNotBundleTheRejectedVideo() throws Exception {
        var normal = ImageIO.read(Path.of("src/main/resources/assets/emipokemon/textures/gui/gacha/standard_gacha.png").toFile());
        var emi = ImageIO.read(Path.of("src/main/resources/assets/emipokemon/textures/gui/gacha/emi_gacha.png").toFile());
        assertEquals(1536, normal.getWidth()); assertEquals(1024, normal.getHeight());
        assertEquals(1536, emi.getWidth()); assertEquals(1024, emi.getHeight());
        assertFalse(Files.exists(Path.of("src/main/resources/assets/emipokemon/textures/gui/gacha/reveal_sheet.png")));
        String screen = source("client/java/com/emipokemon/client/gacha/GachaScreen.java");
        assertFalse(screen.contains("drawRevealAnimation"));
        assertFalse(screen.contains("FRAME_COUNT"));
    }

    @Test void kitsUsePermissionsCooldownAndPersistBeforeConfirmation() throws Exception {
        String commands = source("main/java/com/emipokemon/rewards/KitCommands.java");
        String config = source("main/java/com/emipokemon/config/EmipokemonConfig.java");
        String data = source("main/java/com/emipokemon/data/PlayerData.java");
        assertTrue(commands.contains("JobAccessPolicy.hasPermission"));
        assertTrue(commands.contains("remainingMillis"));
        assertTrue(commands.contains("saveNow(player.getUuid())"));
        assertTrue(config.contains("groups:michivip,michidonador,michimod,michidueñas"));
        assertTrue(data.contains("kitClaims"));
    }

    @Test void adminPanelExposesNewConfigFamilies() throws Exception {
        String admin = source("client/java/com/emipokemon/client/admin/AdminScreen.java");
        String network = source("main/java/com/emipokemon/admin/AdminNetworking.java");
        assertTrue(admin.contains("Pase/Diario"));
        assertTrue(admin.contains("Casino"));
        assertTrue(admin.contains("Kits"));
        assertTrue(network.contains("save_progression"));
        assertTrue(network.contains("save_casino"));
        assertTrue(network.contains("save_kit"));
    }

    @Test void itemsRemainCenteredAfterPhysicalMachineTexturesAreRestored() throws Exception {
        for (String id : List.of("casino_blackjack", "casino_chip_exchange", "casino_claw", "casino_dice",
                "casino_pokemon_flip", "casino_poker", "casino_roulette", "casino_slot",
                "casino_ticket_exchange", "standard_gacha_machine", "emi_gacha_machine")) {
            Path path = Path.of("src/main/resources/assets/emipokemon/textures/block/" + id + ".png");
            var image = ImageIO.read(path.toFile());
            assertEquals(128, image.getWidth(), id); assertEquals(128, image.getHeight(), id);
        }
        for (String id : List.of("michicoin_icon", "random_pokemon_icon")) {
            var image = ImageIO.read(Path.of("src/main/resources/assets/emipokemon/textures/item/" + id + ".png").toFile());
            int minX = image.getWidth(), maxX = -1, minY = image.getHeight(), maxY = -1;
            for (int y = 0; y < image.getHeight(); y++) for (int x = 0; x < image.getWidth(); x++)
                if ((image.getRGB(x, y) >>> 24) != 0) { minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y); }
            assertEquals(31.5D, (minX + maxX) / 2.0D, 1.0D, id);
            assertEquals(31.5D, (minY + maxY) / 2.0D, 1.0D, id);
        }
    }

    @Test void barePokemonIdsAreResolvedInsideCobblemonNamespace() throws Exception {
        String portrait = source("client/java/com/emipokemon/client/render/PokemonPortraitRenderer.java");
        assertTrue(portrait.contains("\"cobblemon:\" + normalized"));
        assertTrue(portrait.contains("normalizeSpeciesId(speciesId)"));
    }

    @Test void clawMarqueeHasPhysicalConnectors() throws Exception {
        JsonObject root = JsonParser.parseString(Files.readString(Path.of(
                "src/main/resources/assets/emipokemon/geo/casino_claw.geo.json"))).getAsJsonObject();
        JsonArray bones = root.getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject().getAsJsonArray("bones");
        String json = bones.toString();
        assertTrue(json.contains("32.0"));
        assertTrue(json.contains("3.8"));
        assertTrue(json.contains("34.1"));
    }
}
