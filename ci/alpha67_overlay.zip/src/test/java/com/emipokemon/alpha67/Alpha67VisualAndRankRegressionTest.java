package com.emipokemon.alpha67;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.junit.jupiter.api.Test;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

final class Alpha67VisualAndRankRegressionTest {
    private static String source(String path) throws Exception { return Files.readString(Path.of("src", path)); }

    @Test void everyRealLuckPermsGroupHasOneCanonicalDefinition() throws Exception {
        String groups = source("main/java/com/emipokemon/progress/RankGroups.java");
        for (String group : new String[]{"default", "michiba", "michidonador", "michidueñas", "michimod", "michivip"})
            assertTrue(groups.contains("\"" + group + "\""), group);
        assertFalse(groups.contains("michidueña\""));
        assertFalse(groups.contains("michiduena"));
    }

    @Test void kitsAcceptExplicitGroupListsAsWellAsPermissionNodes() throws Exception {
        String kits = source("main/java/com/emipokemon/rewards/KitCommands.java");
        String config = source("main/java/com/emipokemon/config/EmipokemonConfig.java");
        assertTrue(kits.contains("startsWith(\"groups:\")"));
        assertTrue(kits.contains("JobAccessPolicy.hasPermission"));
        assertTrue(config.contains("groups:default,michiba,michivip,michidonador,michimod,michidueñas"));
    }

    @Test void alpha66RankDefaultsMigrateWithoutReplacingCustomPermissions() throws Exception {
        String config = source("main/java/com/emipokemon/config/EmipokemonConfig.java");
        assertTrue(config.contains("configVersion = 9"));
        assertTrue(config.contains("migrateLegacyRankGroups()"));
        assertTrue(config.contains("kit.permission.equals(\"emipokemon.kit.vip\")"));
        assertTrue(config.contains("default -> { if (!normalized.isBlank()) migratedPremium.add(normalized); }"));
    }

    @Test void clawHasACompleteCrossRailAndItsMovingAssemblyRemainsConnected() throws Exception {
        JsonObject root = JsonParser.parseString(source("main/resources/assets/emipokemon/geo/casino_claw.geo.json")).getAsJsonObject();
        JsonArray bones = root.getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject().getAsJsonArray("bones");
        String json = bones.toString();
        assertTrue(json.contains("claw_cross_rail"));
        assertTrue(json.contains("12.4"));
        assertTrue(json.contains("11.4"));
        assertTrue(json.contains("claw_carriage"));
    }

    @Test void pokemonTableAndDiceTextStayInsideTheirDecoratedPanels() throws Exception {
        String screen = source("client/java/com/emipokemon/client/casino/CasinoScreen.java");
        assertTrue(screen.contains("panelY + refY(425)"));
        assertTrue(screen.contains("panelY + refY(505)"));
        assertTrue(screen.contains("sw - refX(50)"));
        assertTrue(screen.contains("panelY + refY(900), 0.78F"));
    }
}
