package com.emipokemon.client.render;

import com.cobblemon.mod.common.client.gui.PokemonGuiUtilsKt;
import com.cobblemon.mod.common.client.render.models.blockbench.FloatingState;
import com.cobblemon.mod.common.entity.PoseType;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import org.joml.Quaternionf;

/** Uses Cobblemon 1.7.3's concrete GUI state instead of reflectively constructing abstract PosableState. */
public final class PokemonPortraitRenderer {
    private PokemonPortraitRenderer() { }

    public static boolean draw(DrawContext context, String speciesId, int centerX, int bottomY, int requestedSize) {
        Identifier species = Identifier.tryParse(speciesId);
        if (species == null) return false;
        boolean pushed = false;
        try {
            float outerScale = Math.max(0.55F, requestedSize / 42.0F);
            context.getMatrices().push();
            pushed = true;
            context.getMatrices().translate(centerX, bottomY, 170.0F);
            context.getMatrices().scale(outerScale, outerScale, outerScale);
            PokemonGuiUtilsKt.drawProfilePokemon(
                    species,
                    context.getMatrices(),
                    new Quaternionf(),
                    PoseType.PROFILE,
                    new FloatingState(),
                    0.0F,
                    20.0F,
                    true,
                    false,
                    false,
                    1.0F,
                    1.0F,
                    1.0F,
                    1.0F,
                    0.0F,
                    0.0F
            );
            context.getMatrices().pop();
            return true;
        } catch (Throwable exception) {
            if (pushed) try { context.getMatrices().pop(); } catch (Throwable ignored) { }
            return false;
        }
    }
}
