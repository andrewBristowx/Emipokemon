package com.emipokemon.client.progress;

import com.emipokemon.progress.JournalSnapshot;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.List;

final class QuestJournalScreen extends Screen {
    private static final List<String> TABS = List.of("guide", "tutorial", "progression", "adventure", "jobs");
    private static final List<String> TAB_LABELS = List.of("Guía", "Minecraft", "Pokémon", "Aventura", "Trabajos");

    private final Screen parent;
    private final JournalSnapshot snapshot;
    private final String tab;
    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;

    QuestJournalScreen(Screen parent, JournalSnapshot snapshot, String tab) {
        super(Text.literal("Diario de aventuras"));
        this.parent = parent;
        this.snapshot = snapshot;
        this.tab = TABS.contains(tab) ? tab : "guide";
    }

    Screen parent() {
        return parent;
    }

    @Override
    protected void init() {
        panelWidth = Math.min(720, width - 24);
        panelHeight = Math.min(420, height - 24);
        panelX = (width - panelWidth) / 2;
        panelY = (height - panelHeight) / 2;

        int gap = 6;
        int tabsX = panelX + 18;
        int tabWidth = (panelWidth - 36 - gap * (TABS.size() - 1)) / TABS.size();
        for (int index = 0; index < TABS.size(); index++) {
            String value = TABS.get(index);
            addDrawableChild(new JournalButtonWidget(tabsX + index * (tabWidth + gap), panelY + 42,
                    tabWidth, 20, Text.literal(TAB_LABELS.get(index)), () -> switchTab(value), () -> value.equals(tab)));
        }
        addDrawableChild(new JournalButtonWidget(panelX + panelWidth - 30, panelY + 14, 18, 18,
                Text.literal("×"), this::close));

        if (isMissionTab()) initMissionButtons();
        if ("jobs".equals(tab)) initJobButtons();
    }

    private boolean isMissionTab() {
        return "tutorial".equals(tab) || "progression".equals(tab) || "adventure".equals(tab);
    }

    private void initMissionButtons() {
        JournalSnapshot.QuestView quest = snapshot.quest;
        if (quest != null && quest.complete && !quest.claimed) {
            addDrawableChild(new JournalButtonWidget(panelX + panelWidth - 198, panelY + panelHeight - 42, 178, 22,
                    Text.literal("Reclamar recompensa"), () -> ProgressionClient.sendAction("claim", tab)));
        }
    }

    private void initJobButtons() {
        int rowY = panelY + 84;
        int rowHeight = Math.max(31, Math.min(39, (panelHeight - 132) / Math.max(1, snapshot.jobs.size())));
        for (JournalSnapshot.JobView job : snapshot.jobs) {
            addDrawableChild(new JournalButtonWidget(panelX + panelWidth - 84, rowY + 4, 62, 20,
                    Text.literal(job.active ? "Quitar" : "Elegir"),
                    () -> ProgressionClient.sendAction(job.active ? "job_leave" : "job_join", job.id), () -> job.active));
            rowY += rowHeight;
        }
    }

    private void switchTab(String next) {
        if (!tab.equals(next)) ProgressionClient.requestOpen(next);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, 0xA30A0710);
        drawPanel(context);
        if ("guide".equals(tab)) drawGuide(context);
        else if ("jobs".equals(tab)) drawJobs(context);
        else drawMissions(context);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // The journal draws its own background before Screen renders its widgets.
    }

    private void drawPanel(DrawContext context) {
        context.fill(panelX + 6, panelY + 8, panelX + panelWidth + 6, panelY + panelHeight + 8, 0x82000000);
        context.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xF5140C19);
        context.fill(panelX, panelY, panelX + panelWidth, panelY + 4, 0xFFFF9DDE);
        context.fill(panelX, panelY + 4, panelX + panelWidth, panelY + 7, 0xFF75418E);
        context.fill(panelX, panelY + panelHeight - 4, panelX + panelWidth, panelY + panelHeight, 0xFF75418E);
        context.fill(panelX, panelY, panelX + 3, panelY + panelHeight, 0xFF9D5AAF);
        context.fill(panelX + panelWidth - 3, panelY, panelX + panelWidth, panelY + panelHeight, 0xFF9D5AAF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Diario de aventuras de Emi"),
                panelX + panelWidth / 2, panelY + 20, 0xFFFFD8F1);
        context.fill(panelX + 14, panelY + 70, panelX + panelWidth - 14, panelY + 71, 0x706A3C75);
    }

    private void drawGuide(DrawContext context) {
        int left = panelX + 18;
        int top = panelY + 84;
        int gap = 10;
        int cardWidth = (panelWidth - 46) / 2;
        drawGuideCard(context, left, top, cardWidth, 89, "◆ MICHICOINS",
                "Consíguelas completando misiones, trabajando, capturando, ganando combates y jugando activamente.",
                "Saldo actual: " + snapshot.balance);
        drawGuideCard(context, left + cardWidth + gap, top, cardWidth, 89, "◆ TIRADAS Y TICKETS",
                "Reclama /diario y /pase. Las misiones también entregan tickets. Cada máquina consume su ticket indicado.",
                "Emi = especial · Estándar = normal · Garra = garra");
        drawGuideCard(context, left, top + 99, cardWidth, 89, "◆ PASE DE EMI",
                "Ganas XP al jugar activamente, capturar, combatir, evolucionar, explorar, completar misiones y trabajar.",
                "Cada nivel tiene premio; cada 4 niveles incluye tirada de Emi.");
        drawGuideCard(context, left + cardWidth + gap, top + 99, cardWidth, 89, "◆ TRABAJOS",
                "Elige oficios en la pestaña Trabajos y realiza acciones legítimas. Normal: 2; VIP: 4; staff: todos.",
                "8 XP de trabajo = 1 XP de pase (máx. 12 por minuto).");
        drawGuideCard(context, left, top + 198, cardWidth, 89, "◆ POR DÓNDE EMPEZAR",
                "Abre Minecraft para aprender desde cero. Luego usa Pokémon para tu aventura de entrenador.",
                "Aventura contiene estructuras, altares y desafíos avanzados.");
        drawGuideCard(context, left + cardWidth + gap, top + 198, cardWidth, 89, "◆ CASINO SEGURO",
                "Las mesas muestran coste y estado antes de confirmar. Si una entrega falla, el servidor conserva o devuelve el premio.",
                "Consulta siempre el panel derecho de cada juego.");
    }

    private void drawGuideCard(DrawContext context, int x, int y, int width, int height,
                               String title, String body, String footer) {
        context.fill(x, y, x + width, y + height, 0xA52E1A38);
        context.fill(x, y, x + 4, y + height, 0xFFE37ABF);
        context.drawTextWithShadow(textRenderer, Text.literal(title), x + 11, y + 9, 0xFFFFCDE9);
        drawWrapped(context, body, x + 11, y + 27, width - 22, 0xFFE2D4E3, 3);
        context.drawTextWithShadow(textRenderer, Text.literal(textRenderer.trimToWidth(footer, width - 22)),
                x + 11, y + height - 17, 0xFFFFD36A);
    }

    private void drawMissions(DrawContext context) {
        int leftWidth = Math.min(190, panelWidth / 3);
        int leftX = panelX + 16;
        int top = panelY + 84;
        context.fill(leftX, top, leftX + leftWidth, panelY + panelHeight - 18, 0x8E28152F);
        context.drawTextWithShadow(textRenderer, Text.literal(trackHeading()), leftX + 10, top + 9, 0xFFEAB7DD);
        int chapterY = top + 27;
        for (JournalSnapshot.ChapterView chapter : snapshot.chapters) {
            boolean current = snapshot.quest != null && chapter.id.equals(snapshot.quest.chapter);
            int color = current ? 0xFF613164 : chapter.unlocked ? 0xD73C2346 : 0xA6252028;
            context.fill(leftX + 7, chapterY, leftX + leftWidth - 7, chapterY + 34, color);
            String marker = chapter.unlocked ? (current ? "◆ " : "◇ ") : "[X] ";
            context.drawTextWithShadow(textRenderer, Text.literal(textRenderer.trimToWidth(marker + chapter.title, leftWidth - 24)),
                    leftX + 13, chapterY + 6, current ? 0xFFFFD4ED : 0xFFD2B4CE);
            context.drawTextWithShadow(textRenderer, Text.literal(chapter.complete + "/" + chapter.total), leftX + 13,
                    chapterY + 19, chapter.complete >= chapter.total ? 0xFF91E6B1 : 0xFFAD91AF);
            chapterY += 39;
        }

        int bodyX = leftX + leftWidth + 16;
        int bodyRight = panelX + panelWidth - 18;
        JournalSnapshot.QuestView quest = snapshot.quest;
        if (quest == null) {
            context.drawCenteredTextWithShadow(textRenderer, Text.literal("¡Has completado todas las misiones disponibles!"),
                    (bodyX + bodyRight) / 2, top + 80, 0xFFFFD36A);
            return;
        }
        context.drawTextWithShadow(textRenderer, Text.literal("Capítulo " + quest.chapter + " — " + quest.chapterTitle),
                bodyX, top + 4, 0xFFBD8EC8);
        context.drawTextWithShadow(textRenderer, Text.literal(quest.title), bodyX, top + 24, 0xFFFFCDE9);
        drawWrapped(context, quest.description, bodyX, top + 43, bodyRight - bodyX, 0xFFE2D4E3, 3);

        int objectiveY = top + 104;
        context.fill(bodyX, objectiveY, bodyRight, objectiveY + 64, 0xA52E1A38);
        context.drawTextWithShadow(textRenderer, Text.literal("OBJETIVO"), bodyX + 10, objectiveY + 8, 0xFFF5A8D5);
        context.drawTextWithShadow(textRenderer, Text.literal(textRenderer.trimToWidth(quest.objective, bodyRight - bodyX - 95)),
                bodyX + 10, objectiveY + 24, 0xFFFFFFFF);
        String progress = quest.progress + " / " + quest.target;
        context.drawTextWithShadow(textRenderer, Text.literal(progress), bodyRight - textRenderer.getWidth(progress) - 10,
                objectiveY + 24, quest.complete ? 0xFF9CF0B6 : 0xFFFFE6F6);
        int barLeft = bodyX + 10;
        int barRight = bodyRight - 10;
        int filled = (int) ((barRight - barLeft) * MathHelper.clamp((double) quest.progress / Math.max(1L, quest.target), 0.0D, 1.0D));
        context.fill(barLeft, objectiveY + 43, barRight, objectiveY + 52, 0xFF170D1B);
        context.fill(barLeft + 1, objectiveY + 44, barLeft + Math.max(1, filled), objectiveY + 51,
                quest.complete ? 0xFF73D99A : 0xFFE37ABF);

        int rewardY = objectiveY + 76;
        context.drawTextWithShadow(textRenderer, Text.literal("RECOMPENSAS"), bodyX, rewardY, 0xFFF5A8D5);
        context.drawTextWithShadow(textRenderer, Text.literal(quest.coins + " Michicoins"), bodyX, rewardY + 18, 0xFFFFD36A);
        context.drawTextWithShadow(textRenderer, Text.literal("+" + quest.battlePassXp + " XP de pase"),
                bodyX, rewardY + 33, 0xFFFF9DDE);
        int itemY = rewardY + 49;
        for (String item : quest.items) {
            context.drawTextWithShadow(textRenderer, Text.literal("• " + friendlyItem(item)), bodyX, itemY, 0xFFDCC5DE);
            itemY += 13;
        }
        context.drawTextWithShadow(textRenderer,
                Text.literal(trackName() + ": " + snapshot.completedQuests + "/" + snapshot.totalQuests),
                leftX + 10, panelY + panelHeight - 33, 0xFFAD91AF);
    }

    private void drawJobs(DrawContext context) {
        int rowY = panelY + 84;
        int rowHeight = Math.max(31, Math.min(39, (panelHeight - 132) / Math.max(1, snapshot.jobs.size())));
        for (JournalSnapshot.JobView job : snapshot.jobs) {
            int color = job.active ? 0xD04B2B58 : 0xA52B1934;
            context.fill(panelX + 18, rowY, panelX + panelWidth - 18, rowY + rowHeight - 3, color);
            if (job.active) context.fill(panelX + 18, rowY, panelX + 22, rowY + rowHeight - 3, 0xFFFF9DDE);
            context.drawTextWithShadow(textRenderer, Text.literal((job.active ? "◆ " : "◇ ") + job.name + "  Nv. " + job.level),
                    panelX + 30, rowY + 5, job.active ? 0xFFFFD6ED : 0xFFE8CAE1);
            context.drawTextWithShadow(textRenderer, Text.literal(textRenderer.trimToWidth(job.description, panelWidth - 330)),
                    panelX + 30, rowY + 18, 0xFFB99DB7);
            int barLeft = panelX + panelWidth - 230;
            int barRight = panelX + panelWidth - 94;
            double fraction = job.nextLevel <= job.levelStart ? 1.0D
                    : (double) (job.xp - job.levelStart) / (double) (job.nextLevel - job.levelStart);
            int filled = (int) ((barRight - barLeft) * MathHelper.clamp(fraction, 0.0D, 1.0D));
            context.fill(barLeft, rowY + 10, barRight, rowY + 17, 0xFF160D1A);
            context.fill(barLeft + 1, rowY + 11, barLeft + Math.max(1, filled), rowY + 16, 0xFFE27BBD);
            rowY += rowHeight;
        }
        String slots = snapshot.maxActiveJobs >= snapshot.jobs.size()
                ? "Trabajos activos: " + snapshot.activeJobCount + " / todos"
                : "Trabajos activos: " + snapshot.activeJobCount + " / " + snapshot.maxActiveJobs;
        context.drawTextWithShadow(textRenderer, Text.literal(slots), panelX + 20, panelY + panelHeight - 39, 0xFFCCB4CC);
        context.drawTextWithShadow(textRenderer,
                Text.literal("Progreso del pase: 1 XP por cada 8 XP de trabajo · límite 12 XP/minuto"),
                panelX + 20, panelY + panelHeight - 25, 0xFFFFD36A);
    }

    private String trackHeading() {
        return "tutorial".equals(tab) ? "TUTORIAL" : "CAPÍTULOS";
    }

    private String trackName() {
        return switch (tab) {
            case "tutorial" -> "Minecraft";
            case "adventure" -> "Aventura";
            default -> "Pokémon";
        };
    }

    private String friendlyItem(String value) {
        return value.replace("minecraft:", "").replace("cobblemon:", "").replace("emipokemon:", "")
                .replace('_', ' ');
    }

    private void drawWrapped(DrawContext context, String value, int x, int y, int width, int color, int maxLines) {
        List<OrderedText> lines = textRenderer.wrapLines(Text.literal(value), width);
        for (int index = 0; index < Math.min(maxLines, lines.size()); index++) {
            context.drawTextWithShadow(textRenderer, lines.get(index), x, y + index * 11, color);
        }
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
