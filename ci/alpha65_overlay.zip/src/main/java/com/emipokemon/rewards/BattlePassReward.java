package com.emipokemon.rewards;

/** Deterministic reward for one level and one track of the infinite pass. */
public record BattlePassReward(String type, String itemId, int amount, String label) {
    public static final String ITEM = "ITEM";
    public static final String MICHICOINS = "MICHICOINS";

    public static BattlePassReward item(String itemId, int amount, String label) {
        return new BattlePassReward(ITEM, itemId, amount, label);
    }

    public static BattlePassReward coins(int amount) {
        return new BattlePassReward(MICHICOINS, "emipokemon:michicoin_icon", amount, "Michicoins");
    }
}
